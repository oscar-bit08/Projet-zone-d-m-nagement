-- database.sql
-- Base de données des zones de la métropole lyonnaise

DROP TABLE IF EXISTS zones;

CREATE TABLE zones (
    id INTEGER PRIMARY KEY,
    nom TEXT NOT NULL,
    arrondissement INTEGER,
    lat REAL NOT NULL,
    lng REAL NOT NULL,
    prix_m2 INTEGER,
    nb_ecoles INTEGER DEFAULT 0,
    nb_creches INTEGER DEFAULT 0,
    score_transport REAL DEFAULT 0,
    score_vert REAL DEFAULT 0,
    score_commerce REAL DEFAULT 0,
    description TEXT
);

-- LYON (17 zones)
INSERT INTO zones VALUES
(1, 'Lyon 1 - Terreaux', 1, 45.7676, 4.8345, 5500, 2, 1, 9.5, 5.0, 10.0, 'Hyper-centre culturel, vie nocturne'),
(2, 'Lyon 2 - Bellecour', 2, 45.7577, 4.8322, 6000, 4, 3, 10.0, 7.0, 10.0, 'Prestige, commerces haut de gamme'),
(3, 'Lyon 2 - Confluence', 2, 45.7406, 4.8186, 5200, 5, 4, 8.5, 9.0, 8.0, 'Quartier moderne, architecture contemporaine'),
(4, 'Lyon 3 - Part-Dieu', 3, 45.7606, 4.8556, 4500, 8, 5, 10.0, 6.0, 9.5, 'Quartier d''affaires, centre commercial'),
(5, 'Lyon 3 - Montchat', 3, 45.7547, 4.8767, 3800, 6, 4, 8.0, 7.5, 8.0, 'Résidentiel, esprit village'),
(6, 'Lyon 4 - Croix-Rousse', 4, 45.7784, 4.8282, 4300, 7, 5, 8.5, 8.0, 9.0, 'Colline des canuts, marché quotidien'),
(7, 'Lyon 5 - Vieux Lyon', 5, 45.7626, 4.8270, 4800, 3, 2, 7.5, 6.0, 7.0, 'Patrimoine UNESCO, traboules'),
(8, 'Lyon 5 - Point du Jour', 5, 45.7509, 4.7987, 4000, 5, 4, 6.5, 8.5, 7.0, 'Résidentiel calme, vue panoramique'),
(9, 'Lyon 6 - Tête d''Or', 6, 45.7733, 4.8506, 6500, 10, 7, 9.5, 10.0, 9.0, 'Parc mythique, quartier prisé'),
(10, 'Lyon 6 - Foch', 6, 45.7694, 4.8447, 7000, 8, 6, 9.5, 8.0, 10.0, 'Quartier bourgeois, immeubles haussmanniens'),
(11, 'Lyon 7 - Gerland', 7, 45.7267, 4.8375, 3900, 6, 5, 8.0, 8.0, 7.0, 'Stade LOU, halle Tony Garnier'),
(12, 'Lyon 7 - Jean Macé', 7, 45.7461, 4.8422, 4700, 7, 5, 9.5, 7.0, 9.0, 'Quartier cosmopolite, marché animé'),
(13, 'Lyon 8 - Mermoz', 8, 45.7350, 4.8820, 3200, 7, 5, 8.5, 7.5, 7.0, 'Grand ensemble, quartier populaire'),
(14, 'Lyon 8 - Monplaisir', 8, 45.7413, 4.8737, 3500, 9, 6, 8.0, 7.0, 8.5, 'Quartier familial, nombreuses écoles'),
(15, 'Lyon 8 - États-Unis', 8, 45.7345, 4.8642, 3300, 8, 5, 7.5, 8.0, 7.5, 'Résidentiel abordable, calme'),
(16, 'Lyon 9 - Vaise', 9, 45.7808, 4.8045, 3600, 7, 5, 8.5, 7.0, 8.0, 'Berges de Saône, proche Île Barbe'),
(17, 'Lyon 9 - Duchère', 9, 45.7889, 4.7967, 2800, 6, 4, 6.5, 9.0, 6.0, 'Renouvellement urbain, vue panoramique');

-- VILLEURBANNE (9 zones)
INSERT INTO zones VALUES
(18, 'Villeurbanne - Gratte-Ciel', 0, 45.7697, 4.8804, 4200, 8, 5, 9.8, 6.5, 9.5, 'Architecture art déco, centre-ville'),
(19, 'Villeurbanne - Charpennes', 0, 45.7711, 4.8635, 3900, 7, 5, 10.0, 6.0, 9.0, 'Quartier étudiant, vie nocturne'),
(20, 'Villeurbanne - Gare Villeurbanne', 0, 45.7658, 4.8846, 3500, 6, 4, 8.8, 6.5, 7.5, 'Gare SNCF, habitat mixte'),
(21, 'Villeurbanne - Granclement', 0, 45.7722, 4.8945, 3400, 5, 4, 8.2, 7.0, 7.0, 'Résidentiel calme, pavillonnaire'),
(22, 'Villeurbanne - La Doua', 0, 45.7826, 4.8754, 3100, 4, 3, 9.2, 7.5, 6.0, 'Campus INSA, écoles d''ingénieurs'),
(23, 'Villeurbanne - Cusset', 0, 45.7642, 4.8935, 3400, 6, 4, 7.5, 7.0, 7.5, 'Marché local, ambiance familiale'),
(24, 'Villeurbanne - Tonkin/Feyssine', 0, 45.7834, 4.8673, 3200, 5, 4, 8.0, 8.5, 6.5, 'Parc Feyssine, quartier en mutation'),
(25, 'Villeurbanne - Reconnaissance Balzac', 0, 45.7580, 4.8710, 3600, 5, 4, 8.5, 6.5, 7.0, 'Quartier populaire, vie associative'),
(26, 'Villeurbanne - Sept Chemins', 0, 45.7460, 4.8910, 3200, 4, 3, 8.2, 7.0, 6.5, 'Quartier excentré, habitat mixte');

-- BRON (3 zones)
INSERT INTO zones VALUES
(27, 'Bron - Vinatier/Essarts', 0, 45.7380, 4.9020, 2900, 6, 5, 8.0, 8.0, 6.5, 'Parc du Vinatier, centre hospitalier'),
(28, 'Bron - Parilly', 0, 45.7289, 4.9156, 3000, 7, 5, 7.5, 9.5, 6.5, 'Immense parc, hippodrome, verdoyant'),
(29, 'Bron - Centre', 0, 45.7390, 4.9093, 2900, 5, 4, 7.0, 7.0, 7.0, 'Centre-ville, mairie, marché local');

-- VÉNISSIEUX (2 zones)
INSERT INTO zones VALUES
(30, 'Vénissieux - Centre', 0, 45.6975, 4.8872, 2500, 6, 5, 7.8, 6.5, 7.0, 'Mairie, grand centre commercial'),
(31, 'Vénissieux - Minguettes', 0, 45.6865, 4.8795, 2200, 5, 4, 6.5, 7.0, 5.5, 'Grand ensemble, rénovation urbaine');

-- AUTRES COMMUNES (4 zones)
INSERT INTO zones VALUES
(32, 'Caluire - Centre', 0, 45.7948, 4.8457, 4100, 6, 5, 6.5, 8.5, 7.5, 'Commune résidentielle cossue, esprit village'),
(33, 'Oullins - Centre', 0, 45.7156, 4.8075, 3300, 5, 4, 7.5, 7.0, 7.5, 'Marché couvert historique, vie locale'),
(34, 'Saint-Priest - Centre', 0, 45.6972, 4.9436, 2800, 6, 5, 6.5, 7.5, 7.0, 'Centre commercial Mi-Plaine, habitat diversifié'),
(35, 'Tassin-la-Demi-Lune', 0, 45.7642, 4.7753, 3900, 5, 4, 5.0, 8.0, 7.0, 'Commune verte ouest lyonnais, calme');
