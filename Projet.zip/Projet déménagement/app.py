from flask import Flask, render_template, request
import sqlite3
import os

app = Flask(__name__, template_folder='.', static_folder='.', static_url_path='')

DB_FILE = 'lyon.db'
SQL_FILE = 'database.sql'

# ============================================
# INITIALISATION DE LA BASE
# ============================================
def init_base_si_besoin():
    """Crée la base depuis database.sql si elle n'existe pas"""
    
    # Si la base existe déjà, on ne fait rien
    if os.path.exists(DB_FILE):
        return
    
    print(f"📖 Création de la base depuis {SQL_FILE}...")
    
    # Lit et exécute le SQL
    with open(SQL_FILE, 'r', encoding='utf-8') as f:
        sql_script = f.read()
    
    conn = sqlite3.connect(DB_FILE)
    conn.executescript(sql_script)
    
    # Vérifie le nombre de zones
    cursor = conn.cursor()
    cursor.execute('SELECT COUNT(*) FROM zones')
    nb_zones = cursor.fetchone()[0]
    
    conn.close()
    
    print(f"✅ Base créée avec {nb_zones} zones depuis {SQL_FILE} !")

# ============================================
# CLASSES POO
# ============================================
class Zone:
    def __init__(self, id, nom, arrondissement, lat, lng, prix_m2, 
                 nb_ecoles, nb_creches, score_transport, score_vert, 
                 score_commerce, description):
        self.id = id
        self.nom = nom
        self.arrondissement = arrondissement
        self.lat = lat
        self.lng = lng
        self.prix_m2 = prix_m2
        self.nb_ecoles = nb_ecoles
        self.nb_creches = nb_creches
        self.score_transport = score_transport
        self.score_vert = score_vert
        self.score_commerce = score_commerce
        self.description = description
    
    def est_dans_budget(self, budget):
        if self.prix_m2 is None:
            return True
        prix_total = self.prix_m2 * 70
        return prix_total <= budget
    
    def to_dict(self):
        return {
            'id': self.id,
            'nom': self.nom,
            'arrondissement': self.arrondissement,
            'lat': float(self.lat),
            'lng': float(self.lng),
            'prix_m2': self.prix_m2,
            'nb_ecoles': self.nb_ecoles,
            'nb_creches': self.nb_creches,
            'score_transport': self.score_transport,
            'score_vert': self.score_vert,
            'score_commerce': self.score_commerce,
            'description': self.description
        }

class Preference:
    def __init__(self, nb_enfants, budget, mode_transport, 
                 poids_prix, poids_ecole, poids_transport, 
                 poids_vert, poids_commerce):
        self.nb_enfants = int(nb_enfants)
        self.budget = float(budget)
        self.mode_transport = mode_transport
        self.poids_prix = int(poids_prix)
        self.poids_ecole = int(poids_ecole)
        self.poids_transport = int(poids_transport)
        self.poids_vert = int(poids_vert)
        self.poids_commerce = int(poids_commerce)
        
        self.total_poids = (self.poids_prix + self.poids_ecole + 
                           self.poids_transport + self.poids_vert + 
                           self.poids_commerce)
    
    def get_poids_normalises(self):
        if self.total_poids == 0:
            return {'prix': 20, 'ecole': 20, 'transport': 20, 
                    'vert': 20, 'commerce': 20}
        
        return {
            'prix': round((self.poids_prix / self.total_poids) * 100, 1),
            'ecole': round((self.poids_ecole / self.total_poids) * 100, 1),
            'transport': round((self.poids_transport / self.total_poids) * 100, 1),
            'vert': round((self.poids_vert / self.total_poids) * 100, 1),
            'commerce': round((self.poids_commerce / self.total_poids) * 100, 1)
        }

class CalculateurScore:
    def __init__(self, preference):
        self.pref = preference
    
    def score_prix(self, zone):
        if zone.prix_m2 is None:
            return 50.0
        prix_total = zone.prix_m2 * 70
        if prix_total > self.pref.budget:
            return 0.0
        ratio = prix_total / self.pref.budget
        return round((1 - ratio) * 100, 2)
    
    def score_ecole(self, zone):
        if self.pref.nb_enfants == 0:
            return 50.0
        total = zone.nb_ecoles + zone.nb_creches
        return round(min(100, (total / 17) * 100), 2)
    
    def score_transport(self, zone):
        score = zone.score_transport * 10
        if self.pref.mode_transport == 'metro':
            score = min(100, score * 1.2)
        elif self.pref.mode_transport == 'velo':
            score = min(100, score * 1.1)
        return round(score, 2)
    
    def score_vert(self, zone):
        return round(zone.score_vert * 10, 2)
    
    def score_commerce(self, zone):
        return round(zone.score_commerce * 10, 2)
    
    def score_total(self, zone):
        s_prix = self.score_prix(zone)
        s_ecole = self.score_ecole(zone)
        s_transport = self.score_transport(zone)
        s_vert = self.score_vert(zone)
        s_commerce = self.score_commerce(zone)
        
        if self.pref.total_poids == 0:
            return round((s_prix + s_ecole + s_transport + s_vert + s_commerce) / 5, 2)
        
        score = (
            s_prix * self.pref.poids_prix +
            s_ecole * self.pref.poids_ecole +
            s_transport * self.pref.poids_transport +
            s_vert * self.pref.poids_vert +
            s_commerce * self.pref.poids_commerce
        ) / self.pref.total_poids
        
        return round(score, 2)
    
    def get_details(self, zone):
        return {
            'prix': self.score_prix(zone),
            'ecole': self.score_ecole(zone),
            'transport': self.score_transport(zone),
            'vert': self.score_vert(zone),
            'commerce': self.score_commerce(zone)
        }

# ============================================
# FONCTIONS DB
# ============================================
def get_toutes_zones():
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute('SELECT * FROM zones')
    resultats = c.fetchall()
    
    zones = []
    for row in resultats:
        zone = Zone(
            id=row[0], nom=row[1], arrondissement=row[2],
            lat=row[3], lng=row[4], prix_m2=row[5],
            nb_ecoles=row[6], nb_creches=row[7],
            score_transport=row[8], score_vert=row[9],
            score_commerce=row[10], description=row[11]
        )
        zones.append(zone)
    
    conn.close()
    return zones

def recommander_zones(preference):
    zones = get_toutes_zones()
    calc = CalculateurScore(preference)
    
    resultats = []
    for zone in zones:
        if not zone.est_dans_budget(preference.budget):
            continue
        
        score = calc.score_total(zone)
        resultats.append({
            'zone': zone,
            'score': score,
            'details': calc.get_details(zone)
        })
    
    resultats.sort(key=lambda x: x['score'], reverse=True)
    return resultats

# ============================================
# ROUTES FLASK
# ============================================
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/rechercher', methods=['POST'])
def rechercher():
    try:
        nb_enfants = request.form.get('nb_enfants', 0)
        budget = request.form.get('budget', 500000)
        mode_transport = request.form.get('mode_transport', 'metro')
        poids_prix = request.form.get('poids_prix', 5)
        poids_ecole = request.form.get('poids_ecole', 5)
        poids_transport = request.form.get('poids_transport', 5)
        poids_vert = request.form.get('poids_vert', 5)
        poids_commerce = request.form.get('poids_commerce', 5)
        
        pref = Preference(
            nb_enfants, budget, mode_transport,
            poids_prix, poids_ecole, poids_transport,
            poids_vert, poids_commerce
        )
        
        resultats = recommander_zones(pref)
        
        zones_data = []
        for r in resultats:
            zone_dict = r['zone'].to_dict()
            zone_dict['score'] = r['score']
            zone_dict['details_scores'] = r['details']
            zones_data.append(zone_dict)
        
        poids_normalises = pref.get_poids_normalises()
        
        return render_template(
            'resultats.html',
            zones=zones_data,
            poids=poids_normalises
        )
    
    except Exception as e:
        import traceback
        return f"<h1>Erreur</h1><pre>{traceback.format_exc()}</pre>", 500

# ============================================
# LANCEMENT
# ============================================
if __name__ == '__main__':
    init_base_si_besoin()  # ← LIGNE MANQUANTE !
    print("🚀 Démarrage de l'application...")
    print("🌐 Ouvre http://localhost:5000")
    app.run(debug=True, port=5000)